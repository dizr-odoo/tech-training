{
    'name': 'Motorcycle Registry',
    'summary': """Manage Registration of Motorcycles""",
    'description': """Motorcycle Registry
====================
This Module is used to keep track of the Motorcycle Registration and Ownership of each motorcycled of the brand.""",
    'license': 'OPL-1',
    'author': 'dizr',
    'website': 'https://github.com/dizr-odoo/tech-training',
    'category': 'Kawiil/Kawiil',
    'depends': ['base'],
    'data': [],
    'demo': [],
    'application': True,
}