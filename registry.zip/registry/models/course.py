from odoo import fields, models

class Course(models.Model):
    _name = "motorcycle.registry"
    _description = "Course Info"

    registry_number = fields.Char(required=True)
    vin = fields.Char(required=True)
    first_name = fields.Char(required=True)
    last_name = fields.Char(required=True)
    picture = fields.Image()
    current_mileage = fields.Float()
    license_plat = fields.Char()
    certificate_title = fields.Binary()
    register_date = fields.Date()
    

    #name = fields.Char(string="Title", required = True)
    #active = fields.Boolean(string="Active", default=True)
    #description = fields.Text()
    #level = fields.Selection(string="Level",
    #                         selection=[
    #                             ('beginner', 'Beginner'),
    #                             ('intermediate', 'Intermediate'),
    #                             ('advanced', 'Advanced'),
    #                         ])